﻿using System;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

using WebApplication3.Models;
namespace WebApplication3.Data
{
    public class MySqlContext : DbContext
    {
        public MySqlContext(DbContextOptions<MySqlContext> options) : base(options) { }

        public DbSet<Customer> Customer { get; set; }

        public DbSet<Products> Products { get; set; }

        public virtual DbSet<Quotation> Quotation { get; set; }

        public virtual DbSet<QuationDetails> QuationDetailsList { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
        }
    }
}

