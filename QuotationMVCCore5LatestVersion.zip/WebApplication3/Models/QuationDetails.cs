﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace WebApplication3.Models
{
    public class QuationDetails
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        [Required]
        public int Qdid { get; set; }
        [Required]
        public int Qhid { get; set; }
        [Required]
        public int ProdId { get; set; }
        [Required]
        public string ProdCode { get; set; }
        [Required]
        public string ProdName { get; set; }

        public double Price { get; set; }
        [Required]
        public int Qty { get; set; }
        [Required]
        public double Amount { get; set; }
        [Required]
        public int RowNo { get; set; }
        [Required]
        public virtual Products Prod { get; set; }

        public virtual Quotation QUOTHead { get; set; }
    }
}
