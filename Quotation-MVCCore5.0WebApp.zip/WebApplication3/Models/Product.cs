﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace WebApplication3.Models
{
    public class Products
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        [Required]
        public int ProdId { get; set; }
        [Required]
        [MaxLength(20)]
        public string ProdCode { get; set; }
        [Required]
        [MaxLength(15)]
        public string DivId { get; set; }
        [Required]
        [MaxLength(15)]
        public string CompanyId { get; set; }
        [Required]
        [MaxLength(150)]
        public string ProdName { get; set; }

        public double Price { get; set; }
        [MaxLength(75)]
        public string TestingMethod { get; set; }
        [MaxLength(10)]
        public string GroupId { get; set; }
        [MaxLength(50)]
        public string GroupName { get; set; }

        public int Tax { get; set; }
        [MaxLength(15)]
        public string DepartmentId { get; set; }
        [MaxLength(10)]
        public string Status { get; set; }

        public virtual ICollection<QuationDetails> QuotationDetails { get; set; }
    }
}
