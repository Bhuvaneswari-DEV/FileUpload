﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication3.Models
{
    [Table("Customer")]
    public class Customer
    {

        [Key]
        [Required]
        [MaxLength(15)]
        public string CustomerId { get; set; }
        [Required]
        [MaxLength(10)]
        public string CompanyId { get; set; }
        [Required]

        [MaxLength(50)]
        public string CustomerName { get; set; }
        [Required]

        [MaxLength(35)]
        public string Address { get; set; }
        [MaxLength(35)]
        public string Address2 { get; set; }
        [MaxLength(35)]
        public string Address3 { get; set; }
        [MaxLength(35)]
        public string Address4 { get; set; }
        [MaxLength(50)]
        public string City { get; set; }
        [MaxLength(50)]
        public string Country { get; set; }
        [Required]
        [MaxLength(15)]
        public string Telephone { get; set; }
        [Required]
        [MaxLength(150)]
        public string Email { get; set; }
        [MaxLength(200)]
        public string Website { get; set; }
        [Required]
        [MaxLength(50)]
        public string CreatedUser { get; set; }
        [Required]
        public DateTime CreatedDate { get; set; }
        [MaxLength(35)]
        public string Type { get; set; }
        [MaxLength(35)]
        public string PayTerms { get; set; }
        [MaxLength(35)]
        public string Status { get; set; }
        [MaxLength(35)]
        public string ModifiedUser { get; set; }
        [MaxLength(35)]
        public DateTime ModifiedDate { get; set; }

        public virtual ICollection<Quotation> Quotations { get; set; }
    }
}

