﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace WebApplication3.Models
{
    public class Quotation
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        [Required]
        public int Qhid { get; set; }
        [Required]
        [MaxLength(15)]
        public string QuotationNo { get; set; }
        [Required]
        public DateTime QuotationDate { get; set; }
        [Required]
        public string CustomerId { get; set; }
        [Required]
        [MaxLength(300)]
        public string Subject { get; set; }
        [Required]
        [MaxLength(200)]
        public string Description { get; set; }
        [Required]
        [MaxLength(25)]
        public string Status { get; set; }

        public double Value { get; set; }
        [Required]
        [MaxLength(50)]
        public string CreatedUser { get; set; }
        [Required]
        public DateTime CreatedDate { get; set; }

        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        [Required]
        public virtual Customer Customer { get; set; }

        public virtual List<QuationDetails> QuotationDetailsCollection { get; set; } = new List<QuationDetails>();

    }
}
