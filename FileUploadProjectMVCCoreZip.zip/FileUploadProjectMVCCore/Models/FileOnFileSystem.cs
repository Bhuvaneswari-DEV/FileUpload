﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FileUploadProjectMVCCore.Models
{
    public class FileOnFileSystem:FileModel
    {
        public string FilePath { get; set; }
    }
}
