﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FileUploadProjectMVCCore.Models;
namespace FileUploadProjectMVCCore.Models
{
    public class FileUploadViewModel
    {
        
        public List<FileOnFileSystem> FilesOnFileSystem { get; set; }
        public List<FileOnDatabase> FilesOnDatabase { get; set; }
    }
}
